

<?php $__env->startSection('content'); ?>
<h2>Roles</h2>
<a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary mb-3">Create Role</a>

<table class="table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Permissions</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($role->name); ?></td>
            <td><?php echo e($role->permissions->pluck('name')->join(', ')); ?></td>
            <td>
                <a href="<?php echo e(route('roles.edit', $role->id)); ?>" class="btn btn-warning">Edit</a>
                <form action="<?php echo e(route('roles.destroy', $role->id)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<!-- Pagination links -->
<div class="d-flex justify-content-center mt-4">
   
    <?php echo e($roles->links('pagination::simple-bootstrap-4')); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-learn\secure-auth-system\resources\views/roles/index.blade.php ENDPATH**/ ?>