

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="my-4 text-center">Create New Permission</h2>

        <!-- Display Validation Errors -->
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Form to Create New Permission -->
        <form action="<?php echo e(route('permissions.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <!-- Permission Name Input -->
            <div class="mb-3">
                <label for="name" class="form-label">Permission Name</label>
                <input type="text" class="form-control" id="name" name="name" placeholder="Enter permission name" required value="<?php echo e(old('name')); ?>">
                <small class="form-text text-muted">Provide a unique name for the permission (e.g., "edit-posts", "delete-users").</small>
            </div>

            <!-- Submit Button -->
            <button type="submit" class="btn btn-success btn-lg">Create Permission</button>
            <a href="<?php echo e(route('permissions.index')); ?>" class="btn btn-secondary btn-lg ml-2">Back to Permissions</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-learn\secure-auth-system\resources\views/permissions/create.blade.php ENDPATH**/ ?>