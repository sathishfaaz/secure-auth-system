<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Welcome'); ?></title> <!-- Page-specific title -->
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
    <!-- Bootstrap CSS (If not already included) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">


</head>
<body>


            <!-- Include the header (if you want it in every page) -->
            <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Main Content -->
            <main>
                <?php echo $__env->yieldContent('content'); ?> <!-- Each page will define its own content -->
            </main>

    <!-- Footer Section -->
    <footer>
        <p>&copy; <?php echo e(date('Y')); ?> Our Company. All rights reserved.</p>
        <ul>
            <li><a href="https://facebook.com/ourcompany" target="_blank">Facebook</a></li>
            <li><a href="https://twitter.com/ourcompany" target="_blank">Twitter</a></li>
            <li><a href="https://linkedin.com/company/ourcompany" target="_blank">LinkedIn</a></li>
        </ul>
    </footer>

</body>
</html>
<?php /**PATH D:\Laravel-learn\secure-auth-system\resources\views/layouts/app.blade.php ENDPATH**/ ?>