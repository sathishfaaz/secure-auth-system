<!-- resources/views/admin/audit-logs/index.blade.php -->

  <!-- Assuming you have an admin layout -->

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="mb-4">Audit Logs</h1>

        <!-- Check if there are any logs -->
        <?php if($auditLogs->isEmpty()): ?>
            <div class="alert alert-warning">No audit logs found.</div>
        <?php else: ?>
            <!-- Table for displaying the audit logs -->
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Event</th>
                        <th>Description</th>
                        <th>Auditable</th>
                        <th>User</th>
                        <th>Timestamp</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $auditLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($log->event); ?></td>
                            <td><?php echo e($log->description); ?></td>
                            <td>
                                <!-- Display the auditable's type and ID -->
                                <?php echo e($log->auditable_type); ?> (ID: <?php echo e($log->auditable_id); ?>)
                            </td>
                            <td><?php echo e($log->user->name ?? 'N/A'); ?></td> <!-- Display the user that triggered the action -->
                            <td><?php echo e($log->created_at->format('Y-m-d H:i:s')); ?></td> <!-- Format timestamp -->
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <!-- Pagination links -->
            <div class="d-flex justify-content-center">
                <?php echo e($auditLogs->links()); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-learn\secure-auth-system\resources\views/admin/audit-logs/index.blade.php ENDPATH**/ ?>