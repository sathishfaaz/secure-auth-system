

<?php $__env->startSection('content'); ?>
<h2>Permissions</h2>
<a href="<?php echo e(route('permissions.create')); ?>" class="btn btn-primary mb-3">Create Permission</a>

<!-- Permissions Table -->
<table class="table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($permission->name); ?></td>
            <td>
                <a href="<?php echo e(route('permissions.edit', $permission->id)); ?>" class="btn btn-warning">Edit</a>
                <form action="<?php echo e(route('permissions.destroy', $permission->id)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<!-- Pagination links -->
<div class="d-flex justify-content-center mt-4">
<?php echo e($permissions->links('pagination::simple-bootstrap-4')); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-learn\secure-auth-system\resources\views/permissions/index.blade.php ENDPATH**/ ?>