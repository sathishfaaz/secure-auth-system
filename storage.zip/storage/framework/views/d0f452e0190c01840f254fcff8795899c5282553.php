<!-- resources/views/admin/audit-logs/index.blade.php -->

  <!-- Assuming you have an admin layout -->

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1 class="mb-4">Audit Logs</h1>

        <!-- Check if there are any logs -->
        <?php if($auditLogs->isEmpty()): ?>
            <div class="alert alert-warning">
                <strong>No audit logs found.</strong>
            </div>
        <?php else: ?>
            <!-- Search and Filter Section (Optional) -->
            <div class="mb-4 d-flex justify-content-between">
                <form method="GET" action="<?php echo e(route('audit.logs')); ?>" class="d-flex">
                    <input type="text" name="search" class="form-control me-2" placeholder="Search by event or description" value="<?php echo e(request()->input('search')); ?>">
                    <button class="btn btn-primary" type="submit">Search</button>
                </form>

              
            </div>

            <!-- Table for displaying the audit logs -->
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Event</th>
                            <th>Description</th>
                            <th>Auditable</th>
                            <th>User</th>
                            <th>Timestamp</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $auditLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><strong><?php echo e($log->event); ?></strong></td>
                                <td><?php echo e(\Str::limit($log->description, 50)); ?></td> <!-- Limit description to 50 chars -->
                                <td>
                                    <?php echo e($log->auditable_type); ?> (ID: <?php echo e($log->auditable_id); ?>)
                                </td>
                                <td><?php echo e($log->user->name ?? 'N/A'); ?></td>
                                <td><?php echo e($log->created_at->format('Y-m-d H:i:s')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination links -->
           <div class="d-flex justify-content-center mt-4">
    <?php echo e($auditLogs->links('pagination::simple-bootstrap-4')); ?>

</div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-learn\secure-auth-system\resources\views/admin/audit-log/index.blade.php ENDPATH**/ ?>