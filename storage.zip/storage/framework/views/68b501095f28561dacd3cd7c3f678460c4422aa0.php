

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="my-4 text-center">Assign Permissions to User</h2>

        <!-- Display Validation Errors -->
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('users.assignPermissions', $user->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>

            <!-- Permissions Multi-Select Dropdown -->
            <div class="form-group">
                <label for="permissions">Select Permissions:</label>
                <select name="permissions[]" id="permissions" multiple class="form-control" required>
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($permission->name); ?>" 
                            <?php echo e($user->hasPermissionTo($permission->name) ? 'selected' : ''); ?>>
                            <?php echo e($permission->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <small class="form-text text-muted">Hold down CTRL (Windows) or Command (Mac) to select multiple permissions.</small>
            </div>

            <!-- Submit Button -->
            <button type="submit" class="btn btn-success btn-lg mt-3">Assign Permissions</button>
            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary btn-lg mt-3 ml-2">Back to Users</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-learn\secure-auth-system\resources\views/users/permissions.blade.php ENDPATH**/ ?>