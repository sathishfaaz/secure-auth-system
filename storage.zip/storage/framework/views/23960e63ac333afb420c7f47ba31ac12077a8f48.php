

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="my-4 text-center">Users</h1>
        
        <!-- Add User Button -->
        <div class="text-right mb-3">
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary btn-lg">
                <i class="fas fa-user-plus"></i> Add User
            </a>
        </div>
        
        <!-- Users Table -->
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->roles->pluck('name')->join(', ')); ?></td>
                        <td>
                            <span class="badge <?php echo e($user->is_active ? 'badge-success' : 'badge-danger'); ?>">
                                <?php echo e($user->is_active ? 'Active' : 'Inactive'); ?>

                            </span>
                        </td>
                        <td>
                            <!-- Edit Button -->
                            <a href="<?php echo e(route('users.edit', $user)); ?>" class="btn btn-info btn-sm">
                                <i class="fas fa-edit"></i> Edit
                            </a>

                            <!-- Toggle Status Button -->
                            <form action="<?php echo e(route('users.toggleStatus', $user)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-warning btn-sm">
                                    <i class="fas fa-toggle-on"></i> <?php echo e($user->is_active ? 'Deactivate' : 'Activate'); ?>

                                </button>
                            </form>

                            <!-- Delete Button -->
                            <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </form>

                            <!-- Manage Permissions Button -->
                            <a href="<?php echo e(route('users.editPermissions', $user->id)); ?>" class="btn btn-warning btn-sm">
                                <i class="fas fa-cogs"></i> Manage Permissions
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!-- Pagination links -->
        <div class="d-flex justify-content-center mt-4">
        <?php echo e($users->links('pagination::simple-bootstrap-4')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-learn\secure-auth-system\resources\views/users/index.blade.php ENDPATH**/ ?>