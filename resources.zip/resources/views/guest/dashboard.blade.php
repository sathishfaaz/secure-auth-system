@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Guest Dashboard</h1>
    <p>You have limited access and can only view articles.</p>
</div>
@endsection
