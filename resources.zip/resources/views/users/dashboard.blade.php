@extends('layouts.app')

@section('content')
<div class="container">
    <h1>User Dashboard</h1>
    <p>You can edit and view articles.</p>
</div>
@endsection